package com.atifnaseem.mynotes;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.github.barteksc.pdfviewer.PDFView;

public class ChordKeyActivity extends AppCompatActivity {

    PDFView chordk;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chord_key);

       chordk = (PDFView) findViewById(R.id.pdfchordk);

        chordk.fromAsset("chordk.pdf").load();
    }
}