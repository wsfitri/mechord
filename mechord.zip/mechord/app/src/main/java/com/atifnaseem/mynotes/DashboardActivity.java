package com.atifnaseem.mynotes;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class DashboardActivity extends AppCompatActivity {

    ImageButton bgitar, bpiano;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        bgitar = (ImageButton) findViewById(R.id.gitar);
        bpiano = (ImageButton) findViewById(R.id.piano);


        bgitar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(DashboardActivity.this, GitarActivity.class);
                startActivity(i);
            }
        });

        bpiano.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent u = new Intent(DashboardActivity.this, KeyboardActivity.class);
                startActivity(u);
            }
        });
    }
}
