package com.atifnaseem.mynotes;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.github.barteksc.pdfviewer.PDFView;

public class LirikKeyActivity extends AppCompatActivity {

    PDFView lirikk;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lirik_key);

        lirikk = (PDFView) findViewById(R.id.pdflirikk);

        lirikk.fromAsset("jazz.pdf").load();
    }
}
