package com.atifnaseem.mynotes;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.github.barteksc.pdfviewer.PDFView;

public class ChordGitarActivity extends AppCompatActivity {

    PDFView chordg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chord_gitar);

        chordg = (PDFView) findViewById(R.id.pdfchordg);

        chordg.fromAsset("chordg.pdf").load();
    }
}

