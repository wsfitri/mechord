package com.atifnaseem.mynotes;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class KeyboardActivity extends AppCompatActivity {

    ImageButton klirik, kchord;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_keyboard);



        klirik = (ImageButton) findViewById(R.id.lirik_lagu2);
        kchord = (ImageButton) findViewById(R.id.lirik_chord2);


        klirik.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(KeyboardActivity.this, LirikKeyActivity.class);
                startActivity(i);
            }
        });

        kchord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent u = new Intent(KeyboardActivity.this, ChordKeyActivity.class);
                startActivity(u);
            }
        });

    }
}
