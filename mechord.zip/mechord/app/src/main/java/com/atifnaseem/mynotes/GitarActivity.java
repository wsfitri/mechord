package com.atifnaseem.mynotes;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class GitarActivity extends AppCompatActivity {

    ImageButton glirik, gchord;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gitar);


        glirik = (ImageButton) findViewById(R.id.lirik_lagu);
        gchord = (ImageButton) findViewById(R.id.lirik_chord);


        glirik.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(GitarActivity.this, LirikGitarActivity.class);
                startActivity(i);
            }
        });

        gchord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent u = new Intent(GitarActivity.this, ChordGitarActivity.class);
                startActivity(u);
            }
        });

    }
}
